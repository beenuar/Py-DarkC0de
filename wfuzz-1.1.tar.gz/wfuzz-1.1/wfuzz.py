#!/usr/bin/python
#Covered by GPL V2.0

import urllib
import copy
from reqresp import *
import base64
import binascii
import sys
import md5
import threading
import getopt
import time
import os

class generate_dictio:
	def __init__(self,type,*args):
		self.type=type
		if self.type == "File":
			self.file=args[0]

		elif self.type == "Range" or self.type == "Hexa range":
			self.range=args[0]
			self.min,self.max=self.__limits()
		else:
			raise Exception,"Mode not exist's: " + type


	def __limits(self):
		try:
			ran=self.range.split("-")
			minimum=int(ran[0])
			maximum=int(ran[1])
			return minimum,maximum
		except:
			raise Exception,"Invalid range format: "+self.range

	@staticmethod
	def encode(dictio,encoder,loop=1):
		newdic=[]
		for x in dictio:
			for y in range(0,loop+1):
				if encoder=="urlencode":
					x=urllib.quote(x)
				elif encoder=="base64":
					x=base64.standard_b64encode(x)
				else:
					raise Exception,"Bad encode-string: "+encoder
			newdic.append(x)
		return newdic

	def generate(self):
		if self.type == "File":
				try:
					name=[]
					f = open(self.file, "r")
					for x in f:
						name.append(x.strip())
				except:
					print "Error al abrir el fichero '"+self.file+"'"
					sys.exit(-1)

		elif self.type == "Range":
			name=[]
			for i in range(self.min,self.max+1):
				name.append(str(i))
		elif self.type == "Hexa range":
			name=[]
			for i in range(self.min,self.max+1):
				temp = (str(hex(i)))
				name.append(temp.replace('0x','%'))

		return name


class generate_fuzz:
	def __init__(self,reqresp,dictio,varsSet,proxy=None):

		self.request=reqresp

		self.proxy=proxy

		self.allvars=False
		self.allpost=False
		self.allheaders=False

		if varsSet=="allvars":
			self.allvars=True
		elif varsSet=="allpost":
			self.allpost=True
		elif varsSet=="allheaders":
			self.allheaders=True
		elif varsSet!="None":
			raise Exception,"Unknown variable set: "+varsSet

		self.variablesget=self.request.variablesGET()
		self.variablespost=self.request.variablesPOST()
		self.headers=self.request.getHeaders()

		self.dictio=dictio

	def generate_request(self):
		list=[]
		if self.allvars==True:
			for x in self.variablesget:
				for y in self.dictio:
					copycat=copy.deepcopy(self.request)
					copycat.setProxy(self.proxy)
					copycat.addVariableGET(x,y)
					copycat.description=x + "=" + y
					list.append(copycat)
			return list
		if self.allpost==True:
			for x in self.variablespost:
				for y in self.dictio:
					copycat=copy.deepcopy(self.request)
					copycat.setProxy(self.proxy)
					copycat.addVariablePOST(x,y)
					copycat.description=x + "=" + y
					list.append(copycat)
			return list
		if self.allheaders==True:
			for x in self.headers:
				for y in self.dictio:
					copycat=copy.deepcopy(self.request)
					copycat.setProxy(self.proxy)
					copycat.addHeader(x,y)
					list.append(copycat)
			return list

		rawReq=self.request.getAll()
		if rawReq.count('FUZZ'):
			for x in self.dictio:
				a=Request()
				res=rawReq.replace("FUZZ",x)
				a.parseRequest(res)
				a.completeUrl=self.request.completeUrl.replace("FUZZ",x)
				if self.request.description:
					a.description=self.request.description+"/"+x
				else:
					a.description=x
				a.setProxy(self.proxy)
				list.append(a)

		return list

class FuzzResult:

	def __init__(self,request):
		global OS
		request.setTimeout(6)
		i=0
		while True:
			try:
				request.perform()
				break
			except Exception,a:
				i+=1
				if i==4:
					if __name__=="__main__":
						global nreq
						nreq+=1
						limpialinea()
						sys.stdout.write ("%05d: C=XXX %4d L\t   %5d W\t %s\r\n" %(nreq,0,0,"Error in "+request.description))
						sys.stdout.flush()
						if html:
							sys.stderr.write ("\r\n<tr><td>%05d</td><td>XXX</td><td>%4dL</td><td>%5dW</td><td><a href=%s>%s</a></td></tr>\r\n" %(nreq,0,0,request.completeUrl,"Error in "+request.completeUrl))
						raise a
					return

		content=request.response.getContent()

		self.len=len(content)
		self.lines=content.count("\n")
		self.words=content.count("\n")+content.count(" ")
		self.code=int(request.response.code)

		m=md5.new()
		m.update(content)

		self.md5=m.hexdigest()
		self.req=request
		self.respHeaders=self.req.response.getHeaders()

		del content
		del self.req.response
		del m
		self.req.response=None

		if __name__=="__main__":


			if str(self.code) in hidecodes or str(self.lines) in hidelines or str(self.words) in hidewords:
				fl=""
			else:
				fl="\r\n"
			nreq+=1
			
			imprimeResult (nreq,self.code,self.lines,self.words,self.req.description,fl)

			if html:
				if str(self.code) in hidecodes or str(self.lines) in hidelines or str(self.words) in hidewords:
					return
				imprimeResultHtml (nreq,self.code,self.lines,self.words,self.req)

	def __getitem__ (self,key):
		for i,j in self.respHeaders:
			if key==i:
				return  j
		print "Error al obtener header!!!"


	def has_header (self,key):
		for i,j in self.respHeaders:
			if i==key:
				return True
		return False



#####################################################################################################
#####################################################################################################
#####################################################################################################


class Fuzzer:
	def __init__(self,reqs,threads=20):
		self.reqs=reqs
		self.reqs.reverse()
		self.results=[]
		self.threads=threads
		self.run=True

		self.threads_list=[]

		self.nres=0

		self.mutex=1
		self.Semaphore_Mutex=threading.BoundedSemaphore(value=self.mutex)

	def Launch (self):
		for i in range (0,self.threads):
			th=threading.Thread(target=self.attack, kwargs={})
			th.start()
			self.threads_list.append(th)

	def attack (self):
		rq=self.getNewReq()
		while rq and self.run:
			try :
				res=FuzzResult(rq)
				self.agregaresultado(res)
			except:
				pass
			rq=self.getNewReq()

	def agregaresultado (self,res):
		self.Semaphore_Mutex.acquire()
		self.results.append(res)
		self.nres+=1
		self.Semaphore_Mutex.release()


	def getNewReq(self):
		self.Semaphore_Mutex.acquire()
		if self.reqs:
			res=self.reqs.pop()
		else:
			res=None
		self.Semaphore_Mutex.release()
		return res

	def cleanthreads(self):
		if len(self.reqs):
			return None
		else:
			for i in self.threads_list:
				i.join()
			return True

	def stop(self):
		self.run=False
		for i in self.threads_list:
			i.join()


#############################################################################################################
#############################################################################################################
#################         INTERFACE CONOSLA                                              ####################
#############################################################################################################
#############################################################################################################


OS=os.name
if OS=="nt":
	import WConio

mutex=1
printMutex=threading.BoundedSemaphore(value=mutex)


def imprimeResult (nreq,code,lines,words,fuzzs,finalLine):
	global printMutex

	printMutex.acquire()
	
	limpialinea()
	sys.stdout.write ("%05d:  C=" % (nreq) ) 

	cc=""
	wc=8
	if code>=400 and code<500:
		if color:
			cc="\x1b[31m"
			wc=12
	elif code>=300 and code<400:
		if color:
			cc="\x1b[36m"
			wc=11
	elif code>=200 and code<300:
		if color:
			cc="\x1b[32m"
			wc=10
	else:
		if color:
			cc="\x1b[35m"
			wc=1
	if OS!='nt':
		sys.stdout.write (cc)
	else:
		WConio.textcolor(wc)


	sys.stdout.write ("%03d" % (code)) 
	
	if OS!='nt':
		sys.stdout.write ("\x1b[37m")
	else:
		WConio.textcolor(8)
		
	sys.stdout.write ("   %4d L\t   %5d W\t \"%s\"%s" %(lines,words,fuzzs,finalLine))
	
	sys.stdout.flush()


	printMutex.release()

def limpialinea():
	sys.stdout.write ("\r")
	if OS!='nt':
		sys.stdout.write ("\x1b[0K")
	else:
		WConio.clreol()

def imprimeResultHtml (nreq,code,lines,words,req):
	
	htmlc="<font>"
	if code>=400 and code<500:
			htmlc="<font color=#FF0000>"
	elif code>=300 and code<400:
			htmlc="<font color=#8888FF>"
	elif code>=200 and code<300:
			htmlc="<font color=#00aa00>"

	if req.method.lower()=="get":
		sys.stderr.write ("\r\n<tr><td>%05d</td><td>%s%d</font></td><td>%4dL</td><td>%5dW</td><td><a href=%s>%s</a></td></tr>\r\n" %(nreq,htmlc,code,lines,words,req.completeUrl,req.completeUrl))
	else:
		inputs=""
		postvars=req.variablesPOST()
		for i in postvars:
			inputs+="<input type=\"hidden\" name=\"%s\" value=\"%s\">" % (i,req.getVariablePOST(i))

		sys.stderr.write ("\r\n<tr><td>%05d</td>\r\n<td>%s%d</font></td>\r\n<td>%4dL</td>\r\n<td>%5dW</td>\r\n<td><table><tr><td>%s</td><td><form method=\"post\" action=\"%s\">%s<input type=submit name=b value=\"send POST\"></form></td></tr></table></td>\r\n</tr>\r\n" %(nreq,htmlc,code,lines,words,req.description,req.completeUrl,inputs))






if __name__=="__main__":

	color=False
	hidecodes=[]
	hidewords=[]
	hidelines=[]
	ths=20
	postdata=False
	html=False
	postdata_data=""
	nreq=0

	rlevel=0
	current_depth=0

	banner='''
*************************************
* Wfuzz  1.1 - The web bruteforcer  *
* Coded by:                         *
* Carlos del ojo                    *
*   - deepbit@gmail.com             *
* Christian Martorella              *
*   - cmartorella@edge-security.com *
*************************************
'''
	usage='''
Usage: %s [options] <url>\r\n
Options:
-c	    : Output with colors
-x addr     : use Proxy
-d postdata : Use post data (ex: "id=FUZZ&catalogue=1")
-z dicttype : Specify type od dictionary (file,range,hexa-range)
-r N1-N2    : Specify range limits
-f path     : Specify file path
-t N        : Specify the number of threads (20 default)
-e encoding : [url]encoding or [base64] encoding
-b cookie   : Specify a cookie for the requests
-R depth    : Recursive path discovery
-V alltype  : All parameters fuzzing (allvars and allpost). No need for FUZZ keyword.

--hc N[,N]+ : Hide requests with the specified[s] code
--hl N[,N]+ : Hide responses with the specified[s] number of lines
--hw N[,N]+ : Hide responses with the specified[s] number of words

--html      : Output in HTML format by stderr \r\n

Keyword: FUZZ  wherever you put this word wfuzz will replace by the dictionary.

Example: - wfuzz.py -c -z file -f commons.txt --hc 404 --html http://www.site.com/FUZZ 2> res.html
	   More examples in the README.
''' % (sys.argv[0])



	try:
		opts, args = getopt.getopt(sys.argv[1:], "cx:b:e:R:d:z:r:f:t:w:V:",['hc=','hl=','hw=','html'])
		optsd=dict(opts)
		url=args[0]
		if not "-z" in optsd:
			raise Exception
	except:
		print banner
		print usage
		sys.exit(-1)



	if "-c" in optsd:
		color=True

	if "--html" in optsd:
		html=True
	if "--hc" in optsd:
		hidecodes=optsd["--hc"].split(",")
	if "--hw" in optsd:
		hidewords=optsd["--hw"].split(",")
	if "--hl" in optsd:
		hidelines=optsd["--hl"].split(",")
	payload=optsd ["-z"]
	if optsd ["-z"].lower()=="file":
		dicc=generate_dictio("File",optsd["-f"]).generate()
	elif optsd ["-z"].lower()=="range":
		dicc=generate_dictio("Range",optsd["-r"]).generate()
	elif optsd ["-z"].lower()=="hexa-range":
		dicc=generate_dictio("Hexa range",optsd["-r"]).generate()
	else:
		print "Bad argument: -z dicttype : Specify type od dictionary (file,range,hexa-range)"
		sys.exit (-1)

	if "-e" in optsd:
		if optsd ["-e"].lower()=="url":
			dicc=generate_dictio.encode(dicc,"urlencode")
		elif optsd ["-e"].lower()=="base64":
			dicc=generate_dictio.encode(dicc,"base64")
		else:
			raise Exception



	a=Request()
	a.setUrl(url)

	if "-d" in optsd:
		a.addPostdata(optsd["-d"])

	if "-b" in optsd:
		a.addHeader("Cookie",optsd["-b"])


	proxy=None
	if "-x" in optsd:
		proxy=optsd["-x"]

	if "-t" in optsd:
		ths=int(optsd["-t"])

	if "-R" in optsd:
		rlevel=int(optsd["-R"])
	
	if "-V" in optsd:
		varset=str(optsd["-V"])
	else:
		varset="None"


	gf=generate_fuzz(a,dicc,varset,proxy)
	reqs=gf.generate_request()

	if html:
		sys.stderr.write("<html><head></head><body bgcolor=#000000 text=#FFFFFF><h1>Fuzzing %s</h1>\r\n<table border=\"1\">\r\n<tr><td>#request</td><td>Code</td><td>#lines</td><td>#words</td><td>Url</td></tr>\r\n" % (url) )

	fz=Fuzzer(reqs,ths)
	print banner
	print "Target: " + url
	print "Payload type: " + payload + "\n"

	print "==========================================================="
	print "ID	Response   Lines      Word	 Request    "
	print "===========================================================\r\n"
	fz.Launch()
	try:
		while True:
			if fz.cleanthreads():
				limpialinea()
				print "\r\n"

				if rlevel:

					current_depth+=1
					results=fz.results
					reqs=[]

					for i in results:
						if i.code==200 and i.req.completeUrl[-1]=='/':
							i.req.setUrl(i.req.completeUrl+"FUZZ")
							gf=generate_fuzz(i.req,dicc,"None",proxy)
							reqs+=gf.generate_request()
						elif i.code>=300 and i.code<400:
							if i.has_header("Location") and i["Location"][-1]=='/':
								i.req.setUrl(i["Location"]+"FUZZ")
								gf=generate_fuzz(i.req,dicc,"None",proxy)
								reqs+=gf.generate_request()
						elif i.code==403:
							if i.req.completeUrl[-1]=='/':
								i.req.setUrl(i.req.completeUrl+"FUZZ")
							else:
								i.req.setUrl(i.req.completeUrl+"/FUZZ")
							gf=generate_fuzz(i.req,dicc,"None",proxy)
							reqs+=gf.generate_request()


					if reqs:
						fz=Fuzzer(reqs,ths)
						print "-------------- Recursion level",current_depth,"---------------"
						print
						fz.Launch()

					rlevel-=1
					
					continue

				if html:
					sys.stderr.write("</table></body></html><h5>Wfuzz by EdgeSecurity<h5>\r\n")
				sys.exit(0)

				
			time.sleep(1)
	except KeyboardInterrupt:
		limpialinea()
		sys.stdout.write("Stopping...\r\n")
		
		fz.stop()

	if html:
		sys.stderr.write("</table></body></html><h5>Wfuzz by EdgeSecurity<h5>\r\n")


	limpialinea()
	sys.stdout.write("\r\n")
