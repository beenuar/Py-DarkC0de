Mangle valid file
=================

To fuzz file parser, you can use MangleFile action. It takes a valid file on
input and then injects errors to create invalid file.


Operations
----------

 * replace: replace a byte by a random byte
 * bit: invert one bit value
 * special_value: replace one or more bytes to write a special value,
   eg. four bytes: "0xFF 0xFF 0xFF 0xFF"
 * insert_bytes: insert one or more random bytes
 * delete_bytes: delete one or more bytes


MangleConfig
------------

You can configure some options to help fuzzing using 'config' attribute of
MangleFile. The value is an instance of MangleConfig class. Options:

 * min_op: Minimum number of mangle operations (default: 1)
 * max_op: Maximum number of mangle operations (default: 10)
 * operations: List of operation name (default: ["replace", "bit", "special_value"])
 * max_insert_bytes: Maximum number of insered bytes (default: 8)
 * max_delete_bytes: Maximum number of deleted bytes (default: 8)
 * change_size: Allow operations which change data size (default: False)


Truncate
--------

You can limit maximum file size using 'max_size' attribute of MangleFile.
The value is the maximum number of bytes read from input file.

