PACKAGE = "fusil"
VERSION = "0.8"
WEBSITE = "http://fusil.hachoir.org/"
LICENSE = "GNU GPL v2"
