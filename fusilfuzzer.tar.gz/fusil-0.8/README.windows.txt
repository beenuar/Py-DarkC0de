Status of Windows support
=========================

Fusil doesn't work on Windows currently.

Use --keep-all-sessions command lien option to avoid rmtree() error.

TODO:

 * CreateProcess: write workaround preexec_fn
 * Write limitMemory()

